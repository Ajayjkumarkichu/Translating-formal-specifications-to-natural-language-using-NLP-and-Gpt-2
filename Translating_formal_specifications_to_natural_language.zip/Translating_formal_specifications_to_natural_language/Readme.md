packages:

transformers version: 4.42.3

nltk version:  3.8.1

tokenize version:

re version: 2024.5.15

flask version: 3.0.3

NLP.py
NP.py